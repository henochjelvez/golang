# Python_projects
This is my repository of projects in python for use in audit projects web &amp;  mobile &amp; Api, cloud, infraestructure, wifi, bluetooth, networking, router, iOT, Perimetral networks, SAST, DAST, IAST, api conections, scan kali tools, red teams, blue teams, purple teams, hardening Linux &amp; Windows &amp; Unix &amp; Mac &amp; Aix, Domain controler, and other about IA.

Here you can read and see the use of the different standars for example:
1) OWASP ASVS, MASVS, TOP 10 Mobile, web, api, cloud
https://owasp.org/ 

3) SANS 
https://www.sans.org/

5) CIS Benchmarks
https://www.cisecurity.org/cis-benchmarks

7) CWE 
https://cwe.mitre.org/

8) Mitre attack
https://attack.mitre.org/

9) CVE
https://cve.mitre.org/
https://www.cvedetails.com/


10) CISA
https://www.cisa.gov/known-exploited-vulnerabilities-catalog

11) Other repositores when exploiting systems:

a) nmap
https://nmap.org/book/man-nse.html

b) Rapid7
https://docs.rapid7.com/metasploit/resource-scripts/

c) Metasploit
https://docs.metasploit.com/

d) Exploit db 
https://www.exploit-db.com/

e) Vulners
https://vulners.com/kitploit/KITPLOIT:1562627541384823617
















